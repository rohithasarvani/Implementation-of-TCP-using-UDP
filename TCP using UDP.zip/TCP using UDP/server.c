#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "chunk.h"

#define PORT 8082
#define MAX_CHUNKS 100

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    Chunk chunk;
    char received_message[MAX_CHUNKS * CHUNK_SIZE + 1] = {0}; // Store complete message
    int received_chunks[MAX_CHUNKS] = {0}; // Store received sequence numbers
    int total_received = 0, total_chunks = 0;
    int mode = 0; // Start in receiver mode

    // Create a UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    socklen_t len = sizeof(client_addr);
    printf("Server is listening on port %d\n", PORT);

    while (1) {
        if (mode == 0) { // Receiver mode
            // Receive chunks
            printf("Waiting for incoming message...\n");
            while (total_received < total_chunks || total_chunks == 0) { // Continue until all chunks are received
                int n = recvfrom(sockfd, &chunk, sizeof(Chunk), 0, (struct sockaddr *)&client_addr, &len);
                if (n < 0) continue;

                printf("Received chunk %d: '%s'\n", chunk.seq_num, chunk.data);

                // Simulate ACK loss for every 3rd chunk
                if (chunk.seq_num % 3 != 0) {
                    char ack[10];
                    sprintf(ack, "%d", chunk.seq_num);
                    sendto(sockfd, ack, strlen(ack), 0, (struct sockaddr *)&client_addr, len);
                    printf("Sent ACK for chunk %d\n", chunk.seq_num);
                } else {
                    printf("Skipping ACK for chunk %d\n", chunk.seq_num);
                }

                if (received_chunks[chunk.seq_num - 1] == 0) {
                    strncat(received_message, chunk.data, CHUNK_SIZE); // Append chunk data
                    received_chunks[chunk.seq_num - 1] = 1;
                    total_received++;
                }

                // The total_chunks should be computed only once, and on the first chunk
                if (chunk.seq_num == 1 && total_chunks == 0) {
                    total_chunks = (strlen(chunk.data) + CHUNK_SIZE - 1) / CHUNK_SIZE;
                }

                // Check if all chunks have been received
                if (total_received == total_chunks) {
                    received_message[total_received * CHUNK_SIZE] = '\0'; // Null terminate
                    printf("Assembled message: '%s'\n", received_message);
                    break;
                }
            }

            // Switch to sender mode after receiving all chunks
            printf("Switching to sender mode.\n");
            mode = 1;
        } else { // Sender mode
            char message[256];
            printf("Enter the message to send: ");
            fgets(message, sizeof(message), stdin);
            message[strcspn(message, "\n")] = 0;

            int total_chunks = (strlen(message) + CHUNK_SIZE - 1) / CHUNK_SIZE;
            printf("Total number of chunks to be sent: %d\n", total_chunks);

            for (int i = 0; i < total_chunks; i++) {
                strncpy(chunk.data, message + i * CHUNK_SIZE, CHUNK_SIZE);
                chunk.data[CHUNK_SIZE] = '\0';
                chunk.seq_num = i + 1;

                sendto(sockfd, &chunk, sizeof(Chunk), 0, (struct sockaddr *)&client_addr, len);
                printf("Sent chunk %d: '%s'\n", chunk.seq_num, chunk.data);

                char ack[10];
                int n = recvfrom(sockfd, ack, sizeof(ack), 0, (struct sockaddr *)&client_addr, &len);
                if (n > 0 && atoi(ack) == chunk.seq_num) {
                    printf("Received ACK for chunk %d\n", chunk.seq_num);
                } else {
                    printf("No ACK for chunk %d\n", chunk.seq_num);
                }
            }

            // Switch back to receiver mode
            printf("Switching to receiver mode.\n");
            mode = 0;
        }
    }

    close(sockfd);
    return 0;
}
