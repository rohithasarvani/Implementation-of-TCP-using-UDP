#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <sys/time.h>
#include "chunk.h"

#define PORT 8082
#define MAX_RETRIES 5
#define TIMEOUT_SEC 0
#define TIMEOUT_USEC 100000
#define MAX_CHUNKS 5

void set_timeout(int sockfd) {
    struct timeval timeout;
    timeout.tv_sec = TIMEOUT_SEC;
    timeout.tv_usec = TIMEOUT_USEC;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    Chunk chunk;
    char message[256];
    int mode = 1; // Start as sender mode

    // Create a UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    while (1) {
        if (mode == 1) { // Sender mode
            printf("Enter the message to send: ");
            fgets(message, sizeof(message), stdin);
            message[strcspn(message, "\n")] = 0;

            int total_chunks = (strlen(message) + CHUNK_SIZE - 1) / CHUNK_SIZE;
            printf("Total number of chunks to be sent: %d\n", total_chunks);

            for (int i = 0; i < total_chunks; i++) {
                strncpy(chunk.data, message + i * CHUNK_SIZE, CHUNK_SIZE);
                chunk.data[CHUNK_SIZE] = '\0';
                chunk.seq_num = i + 1;

                int retries = 0;
                while (retries < MAX_RETRIES) {
                    sendto(sockfd, &chunk, sizeof(Chunk), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
                    printf("Sent chunk %d: '%s'\n", chunk.seq_num, chunk.data);

                    set_timeout(sockfd);
                    char ack[10];
                    int n = recvfrom(sockfd, ack, sizeof(ack), 0, NULL, NULL);

                    if (n > 0 && atoi(ack) == chunk.seq_num) {
                        printf("Received ACK for chunk %d\n", chunk.seq_num);
                        break;
                    } else {
                        retries++;
                        printf("No ACK for chunk %d, retry %d\n", chunk.seq_num, retries);
                    }
                }
                if (retries == MAX_RETRIES) {
                    printf("Giving up on chunk %d after %d retries\n", chunk.seq_num, retries);
                }
            }
            mode = 0; // Switch to receiver mode
        } else { // Receiver mode
            socklen_t addr_len = sizeof(server_addr);
            int total_received = 0, total_chunks = 0;
            int received_chunks[MAX_CHUNKS] = {0};
            char received_message[MAX_CHUNKS * CHUNK_SIZE + 1] = {0};

            while (1) {
                int n = recvfrom(sockfd, &chunk, sizeof(Chunk), 0, (struct sockaddr *)&server_addr, &addr_len);
                if (n < 0) continue;

                printf("Received chunk %d: '%s'\n", chunk.seq_num, chunk.data);
                
                if (chunk.seq_num % 3 != 0) {
                    char ack[10];
                    sprintf(ack, "%d", chunk.seq_num);
                    sendto(sockfd, ack, strlen(ack), 0, (struct sockaddr *)&server_addr, addr_len);
                    printf("Sent ACK for chunk %d\n", chunk.seq_num);
                } else {
                    printf("Skipping ACK for chunk %d\n", chunk.seq_num);
                }

                if (received_chunks[chunk.seq_num - 1] == 0) {
                    strncat(received_message, chunk.data, CHUNK_SIZE);
                    received_chunks[chunk.seq_num - 1] = 1;
                    total_received++;
                }

                if (chunk.seq_num == 1) {
                    total_chunks = (strlen(received_message) + CHUNK_SIZE - 1) / CHUNK_SIZE;
                }

                if (total_received == total_chunks) {
                    received_message[total_received * CHUNK_SIZE] = '\0';
                    printf("Assembled message: '%s'\n", received_message);
                    break;
                }
            }
            mode = 1; // Switch to sender mode
        }
    }

    close(sockfd);
    return 0;
}
