#ifndef CHUNK_H
#define CHUNK_H

#define CHUNK_SIZE 5

typedef struct {
    int seq_num;               // Sequence number of the chunk
    char data[CHUNK_SIZE + 1]; // Data chunk (plus one for null terminator)
} Chunk;

#endif // CHUNK_H
